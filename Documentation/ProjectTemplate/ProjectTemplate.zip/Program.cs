﻿using StatiCsharp;

var myAwesomeWebsite = new Website(
    url: "https://yourdomain.com",
    name: "My Awesome Website",
    description: @"Description of your website",
    language: "en-US",
    sections: "posts, about",         //select which folders should be treated as sections
    source: @"/path/to/your/project"  // path to the folder of your website project
    );

myAwesomeWebsite.Make();