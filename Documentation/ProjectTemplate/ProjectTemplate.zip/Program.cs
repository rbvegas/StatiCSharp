﻿using StatiCsharp;

var myAwesomeWebsite = new Website(
    url: "https://yourdomain.com",
    name: "My Awesome Website",
    description: @"Description of your website",
    language: "en-US",
    sections: "posts, about"           // Select which folders should be treated as sections.
);

var manager = new WebsiteManager(
    website: myAwesomeWebsite,
    source: @"/path/to/your/project"    // Path to the folder of your website project.
);

manager.Make();